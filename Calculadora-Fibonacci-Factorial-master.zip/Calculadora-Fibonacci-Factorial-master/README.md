# Calculadora-Fibonacci-Factorial
echo "# Calculadora-Fibonacci-Factorial" >> README.md
git init
git add README.md
git commit -m "first commit"
git remote add origin https://github.com/Mauricio00/Calculadora-Fibonacci-Factorial.git
git push -u origin master
